=============================================================
  FLUORESCENT SPOT COLOR CODE — Recovery Reference
  Generated from: sticker-maker-app
=============================================================

COMPLETE FILES
--------------

1. spot-color-vectors.ts
   - Main PDF export engine for fluorescent spot colors
   - Contains: traceColorRegionsAsync, addSpotColorVectorsToPDF
   - Creates PDF Separation color spaces with OCG (Optional Content Group) layers
   - Marching squares boundary tracing at 300 DPI
   - Even-odd fill rule for proper holes/cutouts
   - Async processing via Web Worker

2. spot-color-worker.ts
   - Web Worker for heavy spot color computation
   - Contains: marching squares algorithm, closest-color mask creation
   - processSpotColors entry point
   - Collinear segment collapse, inch coordinate conversion
   - Runs at 300 DPI for zero UI lag

3. color-extractor.ts
   - Extracts dominant colors from uploaded images
   - Contains: ExtractedColor interface, palette extraction
   - extractDominantColors, extractColorsFromCanvas, extractColorsFromImageAsync
   - Used to populate the fluorescent color assignment UI

4. color-extraction-worker.ts
   - Web Worker version of color extraction
   - Offloads palette detection to background thread


CODE SNIPPETS (from larger files)
----------------------------------

5. SpotColorInput-type.ts
   - From: contour-outline.ts
   - The shared TypeScript interface used across all spot color export functions
   - Fields: hex, rgb, spotWhite, spotGloss, spotFluorY/M/G/Orange + name variants

6. controls-section-fluorescent-code.tsx
   - From: controls-section.tsx
   - Complete fluorescent UI panel code including:
     * ExtractedColor type and SpotPreviewData interface
     * State declarations (spotSelectionsRef, extractedColors, etc.)
     * Color extraction effect with caching and fallback
     * updateSpotColor — toggles Y/M/G/Or assignment (mutually exclusive)
     * sortedColorIndices — prioritizes fluorescent-friendly colors
     * buildSpotColorsForDesign — converts ExtractedColor[] to SpotColorInput[]
     * getAllDesignSpotColors — gathers spot selections across all designs
     * handleDownloadClick — triggers PDF download with spot color data
     * Full JSX for the collapsible fluorescent panel + info accordion

7. preview-section-spot-overlay.tsx
   - From: preview-section.tsx
   - Spot color preview overlay system:
     * Pulse animation (sine wave, 30fps throttled)
     * createSpotOverlayCanvas — pixel-level closest-color matching
     * Fluorescent color mapping: Y=#DFFF00, M=#FF00FF, G=#39FF14, Or=#FF6600
     * Caching system to avoid re-processing unchanged images
     * Tolerance-based color matching (colorTolerance=80, directTolerance=100)

8. image-editor-spot-wiring.tsx
   - From: image-editor.tsx
   - State wiring that connects everything:
     * spotPreviewData state + fluorPanelContainer + copySpotSelectionsRef
     * PDF download handler integration with addSpotColorVectorsToPDF
     * Props passed to ControlsSection and PreviewSection


DATA FLOW
---------
  Upload Image
    → color-extractor.ts extracts palette
    → controls-section.tsx displays colors with Y/M/G/Or buttons
    → User assigns fluorescent inks to colors
    → preview-section.tsx shows pulsing overlay preview
    → On download: buildSpotColorsForDesign → getAllDesignSpotColors
    → spot-color-vectors.ts traces regions via spot-color-worker.ts
    → addSpotColorVectorsToPDF writes Separation layers to PDF

