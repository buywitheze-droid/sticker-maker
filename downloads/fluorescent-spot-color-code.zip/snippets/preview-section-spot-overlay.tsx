// From: client/src/components/preview-section.tsx
// Spot color preview overlay — pulse animation + createSpotOverlayCanvas
// Lines 2125-2251

// ============================================================
// REFS (declared earlier in the component)
// ============================================================

const spotPulseRef = useRef(1);
const spotAnimFrameRef = useRef<number | null>(null);
const spotOverlayCacheRef = useRef<{ key: string; canvas: HTMLCanvasElement } | null>(null);
const createSpotOverlayCanvasRef = useRef<((source?: HTMLImageElement | HTMLCanvasElement) => HTMLCanvasElement | null) | null>(null);

// ============================================================
// SPOT PREVIEW DATA PROP (line 47)
// ============================================================

// Part of the PreviewSection component props:
// spotPreviewData?: { enabled: boolean; colors: Array<{ hex: string; rgb: { r: number; g: number; b: number }; spotWhite?: boolean; spotGloss?: boolean; spotFluorY?: boolean; spotFluorM?: boolean; spotFluorG?: boolean; spotFluorOrange?: boolean }> };

// ============================================================
// PULSE ANIMATION EFFECT (lines 2126-2163)
// ============================================================

useEffect(() => {
  if (!spotPreviewData?.enabled) {
    spotPulseRef.current = 1;
    if (spotAnimFrameRef.current !== null) {
      cancelAnimationFrame(spotAnimFrameRef.current);
      spotAnimFrameRef.current = null;
    }
    spotOverlayCacheRef.current = null;
    if (renderRef.current) renderRef.current();
    return;
  }
  const hasAny = spotPreviewData?.colors?.some(c => c.spotFluorY || c.spotFluorM || c.spotFluorG || c.spotFluorOrange || c.spotWhite || c.spotGloss);
  if (!hasAny) {
    spotPulseRef.current = 1;
    if (spotAnimFrameRef.current !== null) { cancelAnimationFrame(spotAnimFrameRef.current); spotAnimFrameRef.current = null; }
    spotOverlayCacheRef.current = null;
    if (renderRef.current) renderRef.current();
    return;
  }
  let startTime: number | null = null;
  let lastFrameTime = 0;
  const FRAME_INTERVAL = 1000 / 30;
  const animate = (timestamp: number) => {
    if (startTime === null) startTime = timestamp;
    if (timestamp - lastFrameTime >= FRAME_INTERVAL) {
      lastFrameTime = timestamp;
      const elapsed = (timestamp - startTime) / 1000;
      spotPulseRef.current = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(elapsed * Math.PI * 1.5));
      if (renderRef.current) renderRef.current();
    }
    spotAnimFrameRef.current = requestAnimationFrame(animate);
  };
  spotAnimFrameRef.current = requestAnimationFrame(animate);
  return () => {
    if (spotAnimFrameRef.current !== null) { cancelAnimationFrame(spotAnimFrameRef.current); spotAnimFrameRef.current = null; }
    spotPulseRef.current = 1;
  };
}, [spotPreviewData]);

// ============================================================
// CREATE SPOT OVERLAY CANVAS (lines 2165-2249)
// Pixel-level color matching and fluorescent overlay rendering
// ============================================================

const createSpotOverlayCanvas = useCallback((source?: HTMLImageElement | HTMLCanvasElement): HTMLCanvasElement | null => {
  if (!imageInfo || !spotPreviewData?.enabled) return null;
  const allColors = spotPreviewData.colors;
  if (!allColors || allColors.length === 0) return null;

  const fluorY = allColors.filter(c => c.spotFluorY);
  const fluorM = allColors.filter(c => c.spotFluorM);
  const fluorG = allColors.filter(c => c.spotFluorG);
  const fluorOr = allColors.filter(c => c.spotFluorOrange);
  if (fluorY.length === 0 && fluorM.length === 0 && fluorG.length === 0 && fluorOr.length === 0) return null;

  const img = source || imageInfo.image;
  const imgIdentity = (img as HTMLImageElement).src || `${img.width}x${img.height}`;
  const cacheKey = `${imgIdentity}-fy:${fluorY.map(c=>c.hex).join(',')}-fm:${fluorM.map(c=>c.hex).join(',')}-fg:${fluorG.map(c=>c.hex).join(',')}-fo:${fluorOr.map(c=>c.hex).join(',')}`;
  if (spotOverlayCacheRef.current?.key === cacheKey) return spotOverlayCacheRef.current.canvas;

  let ow = img.width, oh = img.height;

  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = ow;
  srcCanvas.height = oh;
  const srcCtx = srcCanvas.getContext('2d');
  if (!srcCtx) return null;
  srcCtx.drawImage(img, 0, 0, ow, oh);
  let srcData: ImageData;
  try { srcData = srcCtx.getImageData(0, 0, ow, oh); } catch { return null; }

  const overlayCanvas = document.createElement('canvas');
  overlayCanvas.width = ow;
  overlayCanvas.height = oh;
  const overlayCtx = overlayCanvas.getContext('2d');
  if (!overlayCtx) return null;
  const overlayData = overlayCtx.createImageData(ow, oh);

  const parseHex = (hex: string) => ({
    r: parseInt(hex.slice(1, 3), 16),
    g: parseInt(hex.slice(3, 5), 16),
    b: parseInt(hex.slice(5, 7), 16),
  });

  const allColorsParsed = allColors.map(c => ({
    ...parseHex(c.hex),
    hex: c.hex,
  }));
  const markedHexMap = new Map<string, { oR: number; oG: number; oB: number }>();
  for (const c of fluorY) markedHexMap.set(c.hex, { oR: 223, oG: 255, oB: 0 });    // #DFFF00
  for (const c of fluorM) markedHexMap.set(c.hex, { oR: 255, oG: 0, oB: 255 });     // #FF00FF
  for (const c of fluorG) markedHexMap.set(c.hex, { oR: 57, oG: 255, oB: 20 });     // #39FF14
  for (const c of fluorOr) markedHexMap.set(c.hex, { oR: 255, oG: 102, oB: 0 });    // #FF6600

  const colorTolerance = 80;
  const directTolerance = 100;
  const alphaThreshold = 128;
  const pixels = srcData.data;
  const out = overlayData.data;

  for (let idx = 0; idx < pixels.length; idx += 4) {
    if (pixels[idx + 3] < alphaThreshold) continue;
    const r = pixels[idx], g = pixels[idx + 1], b = pixels[idx + 2];

    let closestHex = '';
    let closestDist = Infinity;
    for (const ac of allColorsParsed) {
      const dr = r - ac.r, dg = g - ac.g, db = b - ac.b;
      const dist = Math.sqrt(dr * dr + dg * dg + db * db);
      if (dist < closestDist) { closestDist = dist; closestHex = ac.hex; }
    }

    if (closestDist < colorTolerance && markedHexMap.has(closestHex)) {
      const markedRgb = parseHex(closestHex);
      const dr = r - markedRgb.r, dg = g - markedRgb.g, db = b - markedRgb.b;
      if (Math.sqrt(dr * dr + dg * dg + db * db) < directTolerance) {
        const overlay = markedHexMap.get(closestHex)!;
        out[idx] = overlay.oR;
        out[idx + 1] = overlay.oG;
        out[idx + 2] = overlay.oB;
        out[idx + 3] = 255;
      }
    }
  }

  overlayCtx.putImageData(overlayData, 0, 0);
  spotOverlayCacheRef.current = { key: cacheKey, canvas: overlayCanvas };
  return overlayCanvas;
}, [imageInfo, spotPreviewData]);

createSpotOverlayCanvasRef.current = createSpotOverlayCanvas;

// ============================================================
// USAGE IN RENDER (line 2530)
// Inside the draw loop, the overlay is applied to each design:
// ============================================================
// const overlayCanvas = createSpotOverlayCanvasRef.current?.(imageInfo.image) ?? null;
// Then drawn with globalAlpha = spotPulseRef.current over each design
