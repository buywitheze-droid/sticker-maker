// From: client/src/components/controls-section.tsx
// Complete fluorescent spot color UI panel code.
// This file contains: types, state management, color extraction,
// updateSpotColor, buildSpotColorsForDesign, getAllDesignSpotColors,
// and the full fluorescent panel JSX.

// ============================================================
// TYPES & INTERFACE (lines 8-44)
// ============================================================

export interface SpotPreviewData {
  enabled: boolean;
  colors: ExtractedColor[];
}

type ExtractedColor = {
  hex: string;
  name?: string;
  rgb: { r: number; g: number; b: number };
  percentage: number;
  spotWhite?: boolean;
  spotGloss?: boolean;
  spotFluorY?: boolean;
  spotFluorM?: boolean;
  spotFluorG?: boolean;
  spotFluorOrange?: boolean;
};

interface ControlsSectionProps {
  resizeSettings: ResizeSettings;
  onResizeChange: (settings: Partial<ResizeSettings>) => void;
  onDownload: (downloadType?: string, format?: string, spotColorsByDesign?: Record<string, any[]>) => void;
  isProcessing: boolean;
  imageInfo: ImageInfo | null;
  artboardWidth?: number;
  artboardHeight?: number;
  onArtboardHeightChange?: (height: number) => void;
  downloadContainer?: HTMLDivElement | null;
  designCount?: number;
  gangsheetHeights?: number[];
  downloadFormat?: 'png' | 'pdf';
  enableFluorescent?: boolean;
  selectedDesignId?: string | null;
  onSpotPreviewChange?: (data: SpotPreviewData) => void;
  fluorPanelContainer?: HTMLDivElement | null;
  copySpotSelectionsRef?: React.MutableRefObject<((fromId: string, toIds: string[]) => void) | null>;
}

// ============================================================
// STATE DECLARATIONS (lines 67-78)
// ============================================================

const [showSpotColors, setShowSpotColors] = useState(false);
const [showFluorInfo, setShowFluorInfo] = useState(false);
const [extractedColors, setExtractedColors] = useState<ExtractedColor[]>([]);
const [spotPreviewEnabled, setSpotPreviewEnabled] = useState(true);
const spotFluorYName = "FY";
const spotFluorMName = "FM";
const spotFluorGName = "FG";
const spotFluorOrangeName = "FO";
const colorCacheRef = useRef<Map<string, ExtractedColor[]>>(new Map());
const spotSelectionsRef = useRef<Map<string, ExtractedColor[]>>(new Map());
const prevDesignIdRef = useRef<string | null | undefined>(null);

// ============================================================
// COLOR EXTRACTION EFFECT (lines 80-139)
// ============================================================

useEffect(() => {
  if (!enableFluorescent) return;

  let cancelled = false;

  if (prevDesignIdRef.current && extractedColors.length > 0) {
    spotSelectionsRef.current.set(prevDesignIdRef.current, extractedColors);
  }
  prevDesignIdRef.current = selectedDesignId;

  if (imageInfo?.image) {
    if (selectedDesignId && spotSelectionsRef.current.has(selectedDesignId)) {
      setExtractedColors(spotSelectionsRef.current.get(selectedDesignId)!);
    } else {
      const cacheKey = `${imageInfo.image.width}x${imageInfo.image.height}-${imageInfo.file?.name ?? 'unknown'}-${imageInfo.file?.size ?? 0}`;
      const cached = colorCacheRef.current.get(cacheKey);
      if (cached) {
        setExtractedColors(cached.map(c => ({ ...c })));
      } else {
        import("@/lib/color-extractor").then(({ extractColorsFromImageAsync, extractColorsFromImage }) => {
          if (cancelled) return;
          extractColorsFromImageAsync(imageInfo.image, 999).then(colors => {
            if (cancelled) return;
            if (colors.length === 0) {
              try {
                const fallback = extractColorsFromImage(imageInfo.image, 999);
                if (fallback.length > 0) {
                  colorCacheRef.current.set(cacheKey, fallback);
                  setExtractedColors(fallback);
                  return;
                }
              } catch { /* sync fallback failed */ }
            }
            colorCacheRef.current.set(cacheKey, colors);
            if (colorCacheRef.current.size > 20) {
              const firstKey = colorCacheRef.current.keys().next().value;
              if (firstKey) colorCacheRef.current.delete(firstKey);
            }
            setExtractedColors(colors);
          }).catch((err) => {
            if (cancelled) return;
            try {
              const fallback = extractColorsFromImage(imageInfo.image, 999);
              colorCacheRef.current.set(cacheKey, fallback);
              setExtractedColors(fallback);
            } catch { /* sync fallback failed */ }
          });
        }).catch((err) => {
          if (cancelled) return;
          console.warn('[Fluorescent] color-extractor import failed:', err);
        });
      }
    }
  } else {
    setExtractedColors([]);
  }

  return () => { cancelled = true; };
}, [imageInfo, selectedDesignId, enableFluorescent]);

// ============================================================
// COPY SPOT SELECTIONS (for design duplication) (lines 141-155)
// ============================================================

useEffect(() => {
  if (!enableFluorescent || !copySpotSelectionsRef) return;
  copySpotSelectionsRef.current = (fromId: string, toIds: string[]) => {
    if (selectedDesignId && extractedColors.length > 0) {
      spotSelectionsRef.current.set(selectedDesignId, extractedColors);
    }
    const source = spotSelectionsRef.current.get(fromId);
    if (!source) return;
    for (const toId of toIds) {
      spotSelectionsRef.current.set(toId, source.map(c => ({ ...c })));
    }
  };
  return () => { if (copySpotSelectionsRef) copySpotSelectionsRef.current = null; };
}, [copySpotSelectionsRef, selectedDesignId, extractedColors, enableFluorescent]);

// ============================================================
// NOTIFY PARENT OF SPOT PREVIEW CHANGES (lines 157-161)
// ============================================================

useEffect(() => {
  if (!enableFluorescent) return;
  onSpotPreviewChange?.({ enabled: spotPreviewEnabled, colors: extractedColors });
}, [spotPreviewEnabled, extractedColors, onSpotPreviewChange, enableFluorescent]);

// ============================================================
// UPDATE SPOT COLOR (lines 163-179)
// ============================================================

const updateSpotColor = useCallback((index: number, field: 'spotFluorY' | 'spotFluorM' | 'spotFluorG' | 'spotFluorOrange', value: boolean) => {
  setExtractedColors(prev => {
    const updated = prev.map((color, i) => {
      if (i === index) {
        if (value) {
          return { ...color, spotFluorY: false, spotFluorM: false, spotFluorG: false, spotFluorOrange: false, [field]: true };
        }
        return { ...color, [field]: value };
      }
      return color;
    });
    if (selectedDesignId) {
      spotSelectionsRef.current.set(selectedDesignId, updated);
    }
    return updated;
  });
}, [selectedDesignId]);

// ============================================================
// SORTED COLOR INDICES (lines 181-201)
// ============================================================

const sortedColorIndices = useMemo(() => {
  const fluorPriority = (c: ExtractedColor) => {
    const r = c.rgb.r, g = c.rgb.g, b = c.rgb.b;
    const max = Math.max(r, g, b);
    const saturation = max === 0 ? 0 : 1 - Math.min(r, g, b) / max;
    const lightness = (r + g + b) / 3;
    if (saturation < 0.15 || lightness < 40 || lightness > 240) return 1;
    const isMagenta = r > 180 && b > 120 && g < 120;
    const isYellow = r > 180 && g > 160 && b < 100;
    const isGreen = g > 150 && r < 150 && b < 150;
    const isOrange = r > 200 && g > 80 && g < 180 && b < 80;
    const isPink = r > 180 && g < 130 && b > 100;
    const isRed = r > 180 && g < 80 && b < 80;
    if (isMagenta || isYellow || isGreen || isOrange || isPink || isRed) return 0;
    return 1;
  };
  return extractedColors
    .map((c, i) => ({ index: i, priority: fluorPriority(c), pct: c.percentage }))
    .sort((a, b) => a.priority - b.priority || b.pct - a.pct)
    .map(e => e.index);
}, [extractedColors]);

// ============================================================
// BUILD SPOT COLORS FOR DESIGN (lines 203-215)
// ============================================================

const buildSpotColorsForDesign = useCallback((colors: ExtractedColor[]) => colors.map(c => ({
  hex: c.hex,
  rgb: c.rgb,
  spotWhite: false,
  spotGloss: false,
  spotWhiteName: '',
  spotGlossName: '',
  spotFluorY: c.spotFluorY ?? false,
  spotFluorM: c.spotFluorM ?? false,
  spotFluorG: c.spotFluorG ?? false,
  spotFluorOrange: c.spotFluorOrange ?? false,
  spotFluorYName, spotFluorMName, spotFluorGName, spotFluorOrangeName,
})), [spotFluorYName, spotFluorMName, spotFluorGName, spotFluorOrangeName]);

// ============================================================
// GET ALL DESIGN SPOT COLORS (lines 217-229)
// ============================================================

const getAllDesignSpotColors = useCallback(() => {
  if (selectedDesignId && extractedColors.length > 0) {
    spotSelectionsRef.current.set(selectedDesignId, extractedColors);
  }
  const result: Record<string, ReturnType<typeof buildSpotColorsForDesign>> = {};
  for (const [designId, colors] of spotSelectionsRef.current.entries()) {
    result[designId] = buildSpotColorsForDesign(colors);
  }
  if (selectedDesignId && !result[selectedDesignId] && extractedColors.length > 0) {
    result[selectedDesignId] = buildSpotColorsForDesign(extractedColors);
  }
  return result;
}, [selectedDesignId, extractedColors, buildSpotColorsForDesign]);

// ============================================================
// DOWNLOAD CLICK HANDLER (lines 235-242)
// ============================================================

const handleDownloadClick = useCallback(() => {
  if (isPdf && enableFluorescent) {
    const spotColors = getAllDesignSpotColors();
    onDownload('standard', 'pdf', spotColors);
  } else {
    onDownload('standard', 'png');
  }
}, [isPdf, enableFluorescent, getAllDesignSpotColors, onDownload]);

// ============================================================
// FLUORESCENT COLORS PANEL JSX (lines 270-422)
// See full file: controls-section.tsx
// ============================================================
// The panel is portaled into fluorPanelContainer and includes:
// - Collapsible header with Palette icon + "Fluorescent Colors" title
// - Badge showing count of assigned colors
// - Eye/EyeOff toggle for spot preview overlay
// - Color list with Y/M/G/Or assignment buttons per color
// - "How Fluorescent Colors Work" info accordion
// - Available inks grid (Yellow, Magenta, Orange, Green)
// - 3-step instructions
