// From: client/src/components/image-editor.tsx
// Spot color state wiring and PDF export integration

// ============================================================
// IMPORTS (line 4)
// ============================================================
import ControlsSection, { type SpotPreviewData } from "./controls-section";

// ============================================================
// STATE DECLARATIONS (lines 200-202)
// ============================================================
const [spotPreviewData, setSpotPreviewData] = useState<SpotPreviewData>({ enabled: false, colors: [] });
const [fluorPanelContainer, setFluorPanelContainer] = useState<HTMLDivElement | null>(null);
const copySpotSelectionsRef = useRef<((fromId: string, toIds: string[]) => void) | null>(null);

// ============================================================
// DOWNLOAD HANDLER — SPOT COLOR PDF INTEGRATION (lines 2077-2095)
// Inside handleDownload callback, for each design in the gangsheet:
// ============================================================

if (spotColorsByDesign) {
  const designSpotColors = spotColorsByDesign[design.id];
  if (designSpotColors && designSpotColors.length > 0) {
    const hasFluor = designSpotColors.some((c: any) => c.spotFluorY || c.spotFluorM || c.spotFluorG || c.spotFluorOrange);
    if (hasFluor) {
      const offsetXInches = design.transform.nx * artboardWidth - (design.widthInches * design.transform.s) / 2;
      const offsetYInches = design.transform.ny * artboardHeight - (design.heightInches * design.transform.s) / 2;
      await addSpotColorVectorsToPDF(
        pdfDoc, page, img, designSpotColors,
        design.widthInches * design.transform.s,
        design.heightInches * design.transform.s,
        artboardHeight,
        offsetXInches,
        offsetYInches,
        design.transform.rotation ?? 0,
      );
    }
  }
}

// ============================================================
// CONTROLS SECTION PROPS (lines 2280-2297)
// ============================================================

<ControlsSection
  // ...other props...
  downloadFormat={profile.downloadFormat}
  enableFluorescent={profile.enableFluorescent}
  selectedDesignId={selectedDesignId}
  onSpotPreviewChange={setSpotPreviewData}
  fluorPanelContainer={fluorPanelContainer}
  copySpotSelectionsRef={copySpotSelectionsRef}
/>

// Fluorescent panel portal target (line 2300)
{profile.enableFluorescent && <div ref={setFluorPanelContainer} />}

// ============================================================
// PREVIEW SECTION PROPS (line 2675)
// ============================================================

<PreviewSection
  // ...other props...
  spotPreviewData={profile.enableFluorescent ? spotPreviewData : undefined}
/>
